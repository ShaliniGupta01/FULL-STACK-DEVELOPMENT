// Write a JavaScript code snippet to double each number in the given array and log the resulting array to the console.
const numbers = [1, 2, 3, 4, 5];

const result = numbers.map((results) => {
  return results * 2;
});

console.log(result);
